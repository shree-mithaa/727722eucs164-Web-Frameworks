package com.example.cw3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cw3Application {

	public static void main(String[] args) {
		SpringApplication.run(Cw3Application.class, args);
	}

}
