package com.example.cw3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cw3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
