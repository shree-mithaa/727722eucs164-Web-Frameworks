package com.example.cw2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Cw2Application.class, args);
	}

}
