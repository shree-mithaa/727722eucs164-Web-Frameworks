package com.example.cw4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cw4Application {

	public static void main(String[] args) {
		SpringApplication.run(Cw4Application.class, args);
	}

}
